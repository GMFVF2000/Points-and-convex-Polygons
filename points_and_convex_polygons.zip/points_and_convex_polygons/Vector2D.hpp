#ifndef POINTS_AND_CONVEX_POLYGONS_VECTOR2D_HPP
#define POINTS_AND_CONVEX_POLYGONS_VECTOR2D_HPP


class Vector2D
{
public:
    float x_, y_;

    /********** Constructor **********/

    Vector2D();
    Vector2D(const Vector2D &v);
    Vector2D(float x, float y);

    /********** Operator overloading **********/

    Vector2D operator-(const Vector2D &vector2D) const;
    Vector2D operator+(const Vector2D &vector2D) const;
};


#endif //POINTS_AND_CONVEX_POLYGONS_VECTOR2D_HPP
