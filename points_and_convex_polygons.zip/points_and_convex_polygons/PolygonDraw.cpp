#include "PolygonDraw.hpp"
#include <random>

PolygonDraw::PolygonDraw(const string &title, int argc, char **argv, unsigned int width = 800, unsigned int height = 800)
        : GlutWindow(argc, argv, title, width, height, FIXED)
{}

vector<Vector2D> createRandomly(uint number_of_vertex, uint min_value, uint max_value)
{
    vector<Vector2D> vec;
    std::random_device rd;

    for (uint i = 0; i < number_of_vertex; i++)
    {
        float random_number1 = rd() % (max_value - min_value + 1) + min_value;
        float random_number2 = rd() % (max_value - min_value + 1) + min_value;

        vec.push_back(Vector2D(random_number1, random_number2));
    }

    return vec;
}

void PolygonDraw::onStart()
{
    std::cout << "Start.." << std::endl;
    glClearColor(1.0, 1.0, 1.0, 1.0);

    S1_ = new MyPolygon{5};

    S1_->add_vertex(Vector2D{120, 40});
    S1_->add_vertex(Vector2D{400, 160});
    S1_->add_vertex(Vector2D{320, 400});
    S1_->add_vertex(Vector2D{40, 80});
    std::cout << S1_->is_convex();

    S2_ = new MyPolygon{7};

    S2_->add_vertex(Vector2D{620, 40});
    S2_->add_vertex(Vector2D{820, 60});
    S2_->add_vertex(Vector2D{900, 160});
    S2_->add_vertex(Vector2D{820, 400});
    S2_->add_vertex(Vector2D{680, 240});
    S2_->add_vertex(Vector2D{540, 80});
    std::cout << S2_->is_convex();

    S3_ = new MyPolygon{8};

    S3_->add_vertex(Vector2D{500, 500});
    S3_->add_vertex(Vector2D{800, 600});
    S3_->add_vertex(Vector2D{900, 900});
    S3_->add_vertex(Vector2D{400, 900});
    S3_->add_vertex(Vector2D{680, 800});
    S3_->add_vertex(Vector2D{640, 650});
    S3_->add_vertex(Vector2D{240, 680});
    std::cout << S3_->is_convex();

    std::vector<Vector2D> q50 = createRandomly(50, 50,450);
    std::vector<Vector2D> q200 = createRandomly(200, 50, 400);

    S4_ = new MyPolygon(q50);

    S5_ = new MyPolygon(q200);
}

void PolygonDraw::onDraw()
{
    glPushMatrix();

//    S1_->draw();
//    S2_->draw();
//    S3_->draw();
//    S4_->draw();
    S5_->draw();

    glPopMatrix();
}

void PolygonDraw::onQuit()
{
    delete S1_;
    delete S2_;
    delete S3_;
    delete S4_;
    delete S5_;
}

void PolygonDraw::onMouseMove(double cx, double cy)
{

}