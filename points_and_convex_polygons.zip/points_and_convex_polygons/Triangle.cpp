#include "Triangle.hpp"

Triangle::Triangle(Vector2D* ptr1, Vector2D* ptr2, Vector2D* ptr3)
{
    ptr_[0] = ptr1;
    ptr_[1] = ptr2;
    ptr_[2] = ptr3;
}

bool Triangle::is_on_left(const Vector2D* p, const Vector2D* p1, const Vector2D* p2)
{
    Vector2D ab = *p2 - *p1,
            ap = *p - *p1;

    return cross_product(ab, ap) >= 0;
}

bool Triangle::is_empty(const std::vector<Vector2D*> &tmp, int n)
{
    auto p = tmp.begin() + n;
    while(p != tmp.end() && !is_inside(*(*p)))
        p++;

    return p == tmp.end();
}

bool Triangle::is_inside(const Vector2D& p)
{
    return is_on_left(&p, ptr_[0], ptr_[1]) &&
    is_on_left(&p, ptr_[1], ptr_[2]) &&
    is_on_left(&p, ptr_[2], ptr_[0]);
}

float Triangle::cross_product(const Vector2D& ab, const Vector2D& ap)
{
    return (ab.x_ * ap.y_ - ab.y_ * ap.x_);
}