#ifndef POINTS_AND_CONVEX_POLYGONS_TRIANGLE_HPP
#define POINTS_AND_CONVEX_POLYGONS_TRIANGLE_HPP

#include "Vector2D.hpp"
#include <vector>

class Triangle
{
public:
    Vector2D* ptr_[3];

    Triangle(Vector2D* ptr1, Vector2D* ptr2, Vector2D* ptr3);

    bool is_on_left(const Vector2D* p, const Vector2D* p1, const Vector2D* p2);
    float cross_product(const Vector2D& u, const Vector2D& v);
    bool is_empty(const std::vector<Vector2D*> &tmp, int n);
    bool is_inside(const Vector2D& p);
};


#endif //POINTS_AND_CONVEX_POLYGONS_TRIANGLE_HPP
