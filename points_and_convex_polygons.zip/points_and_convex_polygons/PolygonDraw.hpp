#ifndef POINTS_AND_CONVEX_POLYGONS_POLYGONDRAW_HPP
#define POINTS_AND_CONVEX_POLYGONS_POLYGONDRAW_HPP

#include <glutWindow.h>

#include "MyPolygon.hpp"
#include "Vector2D.hpp"

class PolygonDraw: public GlutWindow
{
    MyPolygon* S1_;
    MyPolygon* S2_;
    MyPolygon* S3_;
    MyPolygon* S4_;
    MyPolygon* S5_;

public:
    PolygonDraw(const string& title, int argc, char **argv, unsigned int width, unsigned int height);

    void onStart() override;
    void onDraw() override;
    void onQuit() override;
    void onMouseMove(double cx, double cy) override;
//    void onMouseDown(int button,double cx,double cy) override;
};


#endif //POINTS_AND_CONVEX_POLYGONS_POLYGONDRAW_HPP
