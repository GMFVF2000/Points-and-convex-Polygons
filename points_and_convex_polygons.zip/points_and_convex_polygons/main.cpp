#include <iostream>
#include "PolygonDraw.hpp"

int main(int argc, char **argv)
{
    PolygonDraw polygonDraw{"Polygon draw", argc, argv, 800, 800};
    polygonDraw.start();
    return 0;
}
