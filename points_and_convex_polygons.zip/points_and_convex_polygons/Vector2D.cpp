#include "Vector2D.hpp"

Vector2D::Vector2D()
    : x_{0}, y_{0}
{
}

Vector2D::Vector2D(float x, float y)
    : x_{x}, y_{y}
{
}

Vector2D::Vector2D(const Vector2D &v)
    : x_{v.x_}, y_{v.y_}
{

}

Vector2D Vector2D::operator-(const Vector2D &op2) const
{
    return Vector2D(x_ - op2.x_, y_ - op2.y_);
}

Vector2D Vector2D::operator+(const Vector2D &op2) const
{
    return Vector2D(x_ + op2.x_, y_ + op2.y_);
}
